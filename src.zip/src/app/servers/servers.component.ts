import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servers',
  template: `<app-server></app-server>
             <app-server></app-server>`,
  //styleUrls: ['./servers.component.css']
  styles:[`
      h3{
        color:blue;
      }
    `]
})
export class ServersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
